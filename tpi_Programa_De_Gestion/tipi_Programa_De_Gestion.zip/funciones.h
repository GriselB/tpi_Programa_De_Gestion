#ifndef FUNCIONES_H
#define FUNCIONES_H
#include "structs.h"

using namespace std;

void cargarNombres(Marca marcas[]);
void buscarMarcas(Marca marcas[]);
bool verificarMarcas(Marca marcas[]);
bool buscarProducto(Producto productos[], int codigoProduct);

#endif


