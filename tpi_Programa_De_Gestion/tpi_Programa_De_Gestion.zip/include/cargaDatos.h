#ifndef CARGADATOS_H
#define CARGADATOS_H


class cargaDatos
{
    public:
        cargaDatos();
        virtual ~cargaDatos();

    protected:

    private:
};

#endif // CARGADATOS_H
