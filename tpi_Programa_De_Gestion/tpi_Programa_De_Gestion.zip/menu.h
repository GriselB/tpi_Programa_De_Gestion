#ifndef MENU_H
#define MENU_H
#include "structs.h"
using namespace std;

void mostrarMenu();
bool procesarMenu();
void volverAlMenuPrincipal();
void mostrarMenuReportes(RecaudacionProducto recaudacionProducto[], int productosVendidos);

#endif
