#ifndef REPORTES_H
#define REPORTES_H
using namespace std;

void reporteRecaudacionPorProducto(RecaudacionProducto recaudacionProducto[], int cantidad);

#endif
